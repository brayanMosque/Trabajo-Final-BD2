from django.urls import path
from . import views

urlpatterns = [
    path('migrate/', views.migrate_data, name='api_migrate_data'),
    path('query/', views.execute_query, name='api_execute_query'),
    path('procedure/', views.execute_procedure, name='api_execute_procedure'),
]

