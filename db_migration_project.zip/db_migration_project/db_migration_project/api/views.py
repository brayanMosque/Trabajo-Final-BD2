from rest_framework.decorators import api_view
from rest_framework.response import Response
from core.modules.data_migration import DataMigration
from core.modules.query_manager import QueryManager
from core.modules.stored_procedures import StoredProcedures

@api_view(['POST'])
def migrate_data(request):
    source_db = request.data.get('source_db')
    target_db = request.data.get('target_db')
    table_name = request.data.get('table_name')

    try:
        if target_db == 'mongodb':
            DataMigration.mysql_to_mongodb(table_name)
        elif target_db == 'cassandra':
            DataMigration.mysql_to_cassandra(table_name)
        return Response({'message': f'Data migrated successfully from {source_db} to {target_db}'})
    except Exception as e:
        return Response({'error': str(e)}, status=400)

@api_view(['POST'])
def execute_query(request):
    db_type = request.data.get('db_type')
    query = request.data.get('query')

    try:
        result = QueryManager.execute_query(db_type, query)
        return Response({'result': result})
    except Exception as e:
        return Response({'error': str(e)}, status=400)

@api_view(['POST'])
def execute_procedure(request):
    procedure_name = request.data.get('procedure_name')
    args = request.data.get('args', [])

    try:
        result = StoredProcedures.execute_procedure(procedure_name, *args)
        return Response({'result': result})
    except Exception as e:
        return Response({'error': str(e)}, status=400)

