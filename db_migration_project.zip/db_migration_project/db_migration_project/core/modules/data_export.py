import csv
import json
import xml.etree.ElementTree as ET
from .db_connection import DBConnection

class DataExport:
    @staticmethod
    def export_to_csv(db_type, table_name, file_path):
        data = DataExport._get_data(db_type, table_name)
        with open(file_path, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=data[0].keys())
            writer.writeheader()
            for row in data:
                writer.writerow(row)

    @staticmethoddef export_to_json(db_type, table_name, file_path):
        data = DataExport._get_data(db_type, table_name)
        with open(file_path, 'w') as jsonfile:
            json.dump(data, jsonfile, indent=2)

    @staticmethod
    def export_to_xml(db_type, table_name, file_path):
        data = DataExport._get_data(db_type, table_name)
        root = ET.Element("data")
        for row in data:
            record = ET.SubElement(root, "record")
            for key, value in row.items():
                field = ET.SubElement(record, key)
                field.text = str(value)
        tree = ET.ElementTree(root)
        tree.write(file_path, encoding='utf-8', xml_declaration=True)

    @staticmethod
    def _get_data(db_type, table_name):
        if db_type == 'mysql':
            conn = DBConnection.mysql_connect()
            cursor = conn.cursor(dictionary=True)
            cursor.execute(f"SELECT * FROM {table_name}")
            data = cursor.fetchall()
            cursor.close()
            conn.close()
        elif db_type == 'mongodb':
            conn = DBConnection.mongodb_connect()
            data = list(conn[table_name].find({}, {'_id': 0}))
        elif db_type == 'cassandra':
            conn = DBConnection.cassandra_connect()
            rows = conn.execute(f"SELECT * FROM {table_name}")
            data = [dict(row) for row in rows]
        else:
            raise ValueError("Invalid database type")
        return data

Now, let's create a view for data export:

```python file="db_migration_project/core/views/export.py"
import os
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.conf import settings
from ..modules.data_export import DataExport

@login_required
def export_data(request):
    if request.method == 'POST':
        db_type = request.POST.get('db_type')
        table_name = request.POST.get('table_name')
        export_format = request.POST.get('export_format')

        file_name = f"{table_name}_{db_type}.{export_format}"
        file_path = os.path.join(settings.MEDIA_ROOT, 'exports', file_name)

        try:
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            if export_format == 'csv':
                DataExport.export_to_csv(db_type, table_name, file_path)
            elif export_format == 'json':
                DataExport.export_to_json(db_type, table_name, file_path)
            elif export_format == 'xml':
                DataExport.export_to_xml(db_type, table_name, file_path)
            else:
                raise ValueError("Invalid export format")

            messages.success(request, f'Data exported successfully to {file_name}')
            return redirect('download_export', file_name=file_name)
        except Exception as e:
            messages.error(request, f'Error exporting data: {str(e)}')

    return render(request, 'export_data.html')

@login_required
def download_export(request, file_name):
    file_path = os.path.join(settings.MEDIA_ROOT, 'exports', file_name)
    if os.path.exists(file_path):
        with open(file_path, 'rb') as fh:
            response = HttpResponse(fh.read(), content_type="application/octet-stream")
            response['Content-Disposition'] = 'inline; filename=' + os.path.basename(file_path)
            return response
    raise Http404

