from .db_connection import DBConnection
from .data_validator import DataValidator
import logging

logger = logging.getLogger(__name__)

class DataMigration:
    @staticmethod
    def mysql_to_mongodb(table_name):
        mysql_conn = None
        mongodb_conn = None
        try:
            mysql_conn = DBConnection.mysql_connect()
            mongodb_conn = DBConnection.mongodb_connect()

            cursor = mysql_conn.cursor(dictionary=True)
            cursor.execute(f"SELECT * FROM {table_name}")
            data = cursor.fetchall()

            validated_data = DataValidator.validate_mysql_data(data)
            
            result = mongodb_conn[table_name].insert_many(validated_data)
            logger.info(f"Migrated {len(result.inserted_ids)} records from MySQL to MongoDB")

            return len(result.inserted_ids)
        except Exception as e:
            logger.error(f"Error during MySQL to MongoDB migration: {str(e)}")
            raise
        finally:
            if mysql_conn:
                mysql_conn.close()

    @staticmethod
    def mysql_to_cassandra(table_name):
        mysql_conn = None
        cassandra_conn = None
        try:
            mysql_conn = DBConnection.mysql_connect()
            cassandra_conn = DBConnection.cassandra_connect()

            cursor = mysql_conn.cursor(dictionary=True)
            cursor.execute(f"SELECT * FROM {table_name}")
            data = cursor.fetchall()

            validated_data = DataValidator.validate_mysql_data(data)
            
            for row in validated_data:
                placeholders = ', '.join(['%s'] * len(row))
                columns = ', '.join(row.keys())
                values = tuple(row.values())
                query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
                cassandra_conn.execute(query, values)

            logger.info(f"Migrated {len(validated_data)} records from MySQL to Cassandra")

            return len(validated_data)
        except Exception as e:
            logger.error(f"Error during MySQL to Cassandra migration: {str(e)}")
            raise
        finally:
            if mysql_conn:
                mysql_conn.close()

