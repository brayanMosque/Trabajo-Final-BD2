import re
from datetime import datetime

class DataValidator:
    @staticmethod
    def validate_mysql_data(data):
        validated_data = []
        for row in data:
            validated_row = {}
            for key, value in row.items():
                if isinstance(value, datetime):
                    validated_row[key] = value.isoformat()
                elif isinstance(value, str):
                    validated_row[key] = DataValidator.sanitize_string(value)
                else:
                    validated_row[key] = value
            validated_data.append(validated_row)
        return validated_data

    @staticmethod
    def sanitize_string(value):
        # Remove any potential XSS or SQL injection attempts
        value = re.sub(r'<script.*?>.*?</script>', '', value, flags=re.DOTALL)
        value = re.sub(r'[\'";()]', '', value)
        return value

