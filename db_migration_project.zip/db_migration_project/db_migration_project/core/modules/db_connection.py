import mysql.connector
from pymongo import MongoClient
from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider
from django.conf import settings
import time
import logging

logger = logging.getLogger(__name__)

class DBConnection:
    @staticmethod
    def mysql_connect(max_retries=3, delay=5):
        for attempt in range(max_retries):
            try:
                return mysql.connector.connect(
                    host=settings.DATABASES['mysql']['HOST'],
                    user=settings.DATABASES['mysql']['USER'],
                    password=settings.DATABASES['mysql']['PASSWORD'],
                    database=settings.DATABASES['mysql']['NAME']
                )
            except mysql.connector.Error as err:
                logger.error(f"Error connecting to MySQL: {err}")
                if attempt < max_retries - 1:
                    time.sleep(delay)
                else:
                    raise

    @staticmethod
    def mongodb_connect(max_retries=3, delay=5):
        for attempt in range(max_retries):
            try:
                client = MongoClient(settings.DATABASES['mongodb']['HOST'], 
                                     settings.DATABASES['mongodb']['PORT'])
                client.server_info()  # This will raise an exception if connection fails
                return client[settings.DATABASES['mongodb']['NAME']]
            except Exception as err:
                logger.error(f"Error connecting to MongoDB: {err}")
                if attempt < max_retries - 1:
                    time.sleep(delay)
                else:
                    raise

    @staticmethod
    def cassandra_connect(max_retries=3, delay=5):
        auth_provider = PlainTextAuthProvider(
            username=settings.DATABASES['cassandra']['USER'],
            password=settings.DATABASES['cassandra']['PASSWORD']
        )
        for attempt in range(max_retries):
            try:
                cluster = Cluster([settings.DATABASES['cassandra']['HOST']], 
                                  auth_provider=auth_provider)
                return cluster.connect(settings.DATABASES['cassandra']['NAME'])
            except Exception as err:
                logger.error(f"Error connecting to Cassandra: {err}")
                if attempt < max_retries - 1:
                    time.sleep(delay)
                else:
                    raise

