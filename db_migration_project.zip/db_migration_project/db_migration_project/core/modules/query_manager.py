from .db_connection import DBConnection

class QueryManager:
    @staticmethod
    def execute_query(db_type, query):
        if db_type == 'mysql':
            conn = DBConnection.mysql_connect()
            cursor = conn.cursor(dictionary=True)
            cursor.execute(query)
            result = cursor.fetchall()
            cursor.close()
            conn.close()
        elif db_type == 'mongodb':
            conn = DBConnection.mongodb_connect()
            result = list(conn.command(query))
        elif db_type == 'cassandra':
            conn = DBConnection.cassandra_connect()
            result = conn.execute(query)
        else:
            raise ValueError("Unsupported database type")

        return result

