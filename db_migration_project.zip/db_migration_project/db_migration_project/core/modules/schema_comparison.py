from .db_connection import DBConnection

class SchemaComparison:
    @staticmethod
    def get_mysql_schema(table_name):
        conn = DBConnection.mysql_connect()
        cursor = conn.cursor()
        cursor.execute(f"DESCRIBE {table_name}")
        schema = cursor.fetchall()
        cursor.close()
        conn.close()
        return schema

    @staticmethod
    def get_mongodb_schema(collection_name):
        conn = DBConnection.mongodb_connect()
        schema = conn[collection_name].find_one()
        return {k: type(v).__name__ for k, v in schema.items()}

    @staticmethod
    def get_cassandra_schema(table_name):
        conn = DBConnection.cassandra_connect()
        query = f"SELECT column_name, type FROM system_schema.columns WHERE keyspace_name = 'db_migration' AND table_name = '{table_name}'"
        rows = conn.execute(query)
        return {row.column_name: row.type for row in rows}

    @staticmethod
    def compare_schemas(table_name):
        mysql_schema = SchemaComparison.get_mysql_schema(table_name)
        mongodb_schema = SchemaComparison.get_mongodb_schema(table_name)
        cassandra_schema = SchemaComparison.get_cassandra_schema(table_name)

        return {
            'mysql': mysql_schema,
            'mongodb': mongodb_schema,
            'cassandra': cassandra_schema
        }

