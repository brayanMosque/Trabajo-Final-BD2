from .db_connection import DBConnection

class StoredProcedures:
    @staticmethod
    def execute_procedure(procedure_name, *args):
        conn = DBConnection.mysql_connect()
        cursor = conn.cursor(dictionary=True)

        try:
            cursor.callproc(procedure_name, args)
            result = cursor.fetchall()
            conn.commit()
        except mysql.connector.Error as err:
            conn.rollback()
            raise err
        finally:
            cursor.close()
            conn.close()

        return result

