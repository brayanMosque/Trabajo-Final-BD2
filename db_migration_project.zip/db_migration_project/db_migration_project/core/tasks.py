from celery import shared_task
from .modules.data_migration import DataMigration

@shared_task
def scheduled_migration(source_db, target_db, table_name):
    if target_db == 'mongodb':
        return DataMigration.mysql_to_mongodb(table_name)
    elif target_db == 'cassandra':
        return DataMigration.mysql_to_cassandra(table_name)
    else:
        raise ValueError("Invalid target database")

