from functools import wraps
from ..models import AuditLog

def log_action(action):
    def decorator(view_func):
        @wraps(view_func)
        def _wrapped_view(request, *args, **kwargs):
            response = view_func(request, *args, **kwargs)
            AuditLog.objects.create(
                user=request.user,
                action=action,
                details=f"Args: {args}, Kwargs: {kwargs}"
            )
            return response
        return _wrapped_view
    return decorator

