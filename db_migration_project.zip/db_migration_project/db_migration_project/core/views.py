from django.shortcuts import render, redirect
from django.contrib import messages
from .modules.data_migration import DataMigration
from .modules.query_manager import QueryManager
from .modules.stored_procedures import StoredProcedures

def home(request):
    return render(request, 'home.html')

def migrate_data(request):
    if request.method == 'POST':
        source_db = request.POST.get('source_db')
        target_db = request.POST.get('target_db')
        table_name = request.POST.get('table_name')

        try:
            if target_db == 'mongodb':
                DataMigration.mysql_to_mongodb(table_name)
            elif target_db == 'cassandra':
                DataMigration.mysql_to_cassandra(table_name)
            messages.success(request, f'Data migrated successfully from {source_db} to {target_db}')
        except Exception as e:
            messages.error(request, f'Error during migration: {str(e)}')

        return redirect('migrate_data')

    return render(request, 'migrate.html')

def view_data(request):
    data = None
    if request.method == 'POST':
        db_type = request.POST.get('db_type')
        table_name = request.POST.get('table_name')

        try:
            query = f"SELECT * FROM {table_name}"
            data = QueryManager.execute_query(db_type, query)
        except Exception as e:
            messages.error(request, f'Error fetching data: {str(e)}')

    return render(request, 'view_data.html', {'data': data})

def execute_procedure(request):
    result = None
    if request.method == 'POST':
        procedure_name = request.POST.get('procedure_name')
        args = request.POST.get('args', '').split(',')

        try:
            result = StoredProcedures.execute_procedure(procedure_name, *args)
            messages.success(request, 'Procedure executed successfully')
        except Exception as e:
            messages.error(request, f'Error executing procedure: {str(e)}')

    return render(request, 'execute_procedure.html', {'result': result})

