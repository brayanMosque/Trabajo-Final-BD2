from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from ..models import AuditLog

@login_required
def view_audit_log(request):
    logs = AuditLog.objects.all().order_by('-timestamp')
    return render(request, 'audit_log.html', {'logs': logs})

