from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from ..modules.query_manager import QueryManager

@login_required
def dashboard(request):
    mysql_stats = QueryManager.execute_query('mysql', 'SELECT COUNT(*) as count FROM users')
    mongodb_stats = QueryManager.execute_query('mongodb', 'db.users.count()')
    cassandra_stats = QueryManager.execute_query('cassandra', 'SELECT COUNT(*) FROM users')

    recent_migrations = QueryManager.execute_query('mysql', '''
        SELECT source_db, target_db, table_name, created_at 
        FROM migration_log 
        ORDER BY created_at DESC 
        LIMIT 5
    ''')

    context = {
        'mysql_count': mysql_stats[0]['count'],
        'mongodb_count': mongodb_stats[0]['count'],
        'cassandra_count': cassandra_stats[0]['count'],
        'recent_migrations': recent_migrations,
    }

    return render(request, 'dashboard.html', context)

