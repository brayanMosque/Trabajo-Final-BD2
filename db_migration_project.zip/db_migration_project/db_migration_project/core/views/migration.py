from django.shortcuts import render, redirect
from django.contrib import messages
from ..modules.data_migration import DataMigration
from ..utils.decorators import handle_db_exceptions, log_action

@handle_db_exceptions
@log_action("Data Migration")
def migrate_data(request):
    if request.method == 'POST':
        source_db = request.POST.get('source_db')
        target_db = request.POST.get('target_db')
        table_name = request.POST.get('table_name')

        if target_db == 'mongodb':
            migrated_records = DataMigration.mysql_to_mongodb(table_name)
        elif target_db == 'cassandra':
            migrated_records = DataMigration.mysql_to_cassandra(table_name)
        else:
            messages.error(request, 'Invalid target database selected.')
            return redirect('migrate_data')

        messages.success(request, f'Successfully migrated {migrated_records} records from {source_db} to {target_db}')
        return redirect('migrate_data')

    return render(request, 'migrate.html')

