from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from ..tasks import scheduled_migration
from datetime import datetime, timedelta

@login_required
def schedule_migration(request):
    if request.method == 'POST':
        source_db = request.POST.get('source_db')
        target_db = request.POST.get('target_db')
        table_name = request.POST.get('table_name')
        schedule_time = request.POST.get('schedule_time')

        schedule_datetime = datetime.now() + timedelta(hours=int(schedule_time))

        scheduled_migration.apply_async(
            args=[source_db, target_db, table_name],
            eta=schedule_datetime
        )

        messages.success(request, f'Migration scheduled for {schedule_datetime}')
        return redirect('home')

    return render(request, 'schedule_migration.html')

