from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from ..modules.schema_comparison import SchemaComparison

@login_required
def compare_schemas(request):
    comparison_result = None
    if request.method == 'POST':
        table_name = request.POST.get('table_name')
        comparison_result = SchemaComparison.compare_schemas(table_name)

    return render(request, 'compare_schemas.html', {'comparison_result': comparison_result})

