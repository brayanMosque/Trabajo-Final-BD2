from django.shortcuts import render
from ..modules.query_manager import QueryManager

def migration_statistics(request):
    mysql_stats = QueryManager.execute_query('mysql', 'SELECT COUNT(*) as count FROM users')
    mongodb_stats = QueryManager.execute_query('mongodb', 'db.users.count()')
    cassandra_stats = QueryManager.execute_query('cassandra', 'SELECT COUNT(*) FROM users')

    context = {
        'mysql_count': mysql_stats[0]['count'],
        'mongodb_count': mongodb_stats[0]['count'],
        'cassandra_count': cassandra_stats[0]['count'],
    }

    return render(request, 'statistics.html', context)

