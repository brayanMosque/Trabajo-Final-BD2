from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider

def setup_cassandra():
    # Connect to Cassandra
    auth_provider = PlainTextAuthProvider(username='cassandra', password='cassandra')
    cluster = Cluster(['localhost'], auth_provider=auth_provider)
    session = cluster.connect()

    # Create keyspace
    session.execute("""
        CREATE KEYSPACE IF NOT EXISTS db_migration
        WITH replication = {'class': 'SimpleStrategy', 'replication_factor': 1}
    """)

    session.set_keyspace('db_migration')

    # Create tables
    session.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id uuid PRIMARY KEY,
            username text,
            email text
        )
    """)

    session.execute("""
        CREATE TABLE IF NOT EXISTS posts_by_user (
            user_id uuid,
            post_id uuid,
            title text,
            content text,
            created_at timestamp,
            PRIMARY KEY ((user_id), post_id)
        ) WITH CLUSTERING ORDER BY (post_id DESC)
    """)

    # Create indexes
    session.execute("CREATE INDEX IF NOT EXISTS ON users (username)")
    session.execute("CREATE INDEX IF NOT EXISTS ON users (email)")

    print("Cassandra setup completed")

    cluster.shutdown()

if __name__ == "__main__":
    setup_cassandra()

