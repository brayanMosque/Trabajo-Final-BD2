import os
import subprocess
import mysql.connector
from pymongo import MongoClient
from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider

def init_mysql():
    # Execute the MySQL script
    mysql_cmd = f"mysql -u your_mysql_user -p your_mysql_password < {os.path.join(os.path.dirname(__file__), 'mysql_schema.sql')}"
    subprocess.run(mysql_cmd, shell=True, check=True)
    print("MySQL database initialized")

def init_mongodb():
    # Execute the MongoDB script
    mongo_cmd = f"mongo {os.path.join(os.path.dirname(__file__), 'mongodb_setup.js')}"
    subprocess.run(mongo_cmd, shell=True, check=True)
    print("MongoDB database initialized")

def init_cassandra():
    # Execute the Cassandra script
    cassandra_cmd = f"python {os.path.join(os.path.dirname(__file__), 'cassandra_setup.py')}"
    subprocess.run(cassandra_cmd, shell=True, check=True)
    print("Cassandra database initialized")

if __name__ == "__main__":
    init_mysql()
    init_mongodb()
    init_cassandra()
    print("All databases initialized successfully")

