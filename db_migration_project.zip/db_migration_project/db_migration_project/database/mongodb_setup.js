// Connect to MongoDB
const { MongoClient } = require('mongodb');
const url = 'mongodb://localhost:27017';
const dbName = 'db_migration';

async function setupMongoDB() {
  const client = new MongoClient(url);

  try {
    await client.connect();
    console.log('Connected to MongoDB');

    const db = client.db(dbName);

    // Create collections
    await db.createCollection('users');
    await db.createCollection('posts');

    // Create indexes
    await db.collection('users').createIndex({ username: 1 }, { unique: true });
    await db.collection('users').createIndex({ email: 1 }, { unique: true });
    await db.collection('posts').createIndex({ user_id: 1 });

    console.log('MongoDB setup completed');
  } catch (err) {
    console.error('Error setting up MongoDB:', err);
  } finally {
    await client.close();
  }
}

setupMongoDB();

