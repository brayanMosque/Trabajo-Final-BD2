-- Create the database
CREATE DATABASE IF NOT EXISTS db_migration;
USE db_migration;

-- Create tables
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    title VARCHAR(100) NOT NULL,
    content TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert sample data
INSERT INTO users (username, email) VALUES
('john_doe', 'john@example.com'),
('jane_smith', 'jane@example.com'),
('bob_johnson', 'bob@example.com');

INSERT INTO posts (user_id, title, content) VALUES
(1, 'First Post', 'This is the content of the first post.'),
(1, 'Second Post', 'This is the content of the second post.'),
(2, 'Hello World', 'Jane''s first post content.'),
(3, 'Greetings', 'Bob says hello to everyone.');

-- Create a stored procedure
DELIMITER //

CREATE PROCEDURE GetUserPosts(IN userId INT)
BEGIN
    SELECT p.id, p.title, p.content, p.created_at
    FROM posts p
    WHERE p.user_id = userId
    ORDER BY p.created_at DESC;
END //

DELIMITER ;

-- Create a stored procedure to add a new user and their first post
DELIMITER //

CREATE PROCEDURE AddUserWithPost(
    IN p_username VARCHAR(50),
    IN p_email VARCHAR(100),
    IN p_post_title VARCHAR(100),
    IN p_post_content TEXT
)
BEGIN
    DECLARE new_user_id INT;
    
    -- Insert the new user
    INSERT INTO users (username, email) VALUES (p_username, p_email);
    
    -- Get the new user's ID
    SET new_user_id = LAST_INSERT_ID();
    
    -- Insert the user's first post
    INSERT INTO posts (user_id, title, content)
    VALUES (new_user_id, p_post_title, p_post_content);
    
    -- Return the new user's data and their post
    SELECT u.id AS user_id, u.username, u.email, p.id AS post_id, p.title, p.content
    FROM users u
    JOIN posts p ON u.id = p.user_id
    WHERE u.id = new_user_id;
END //

DELIMITER ;

