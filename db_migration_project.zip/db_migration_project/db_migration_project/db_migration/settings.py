# ... (other settings)

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    },
    'mysql': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'db_migration',
        'USER': 'your_mysql_user',
        'PASSWORD': 'your_mysql_password',
        'HOST': 'localhost',
        'PORT': '3306',
    },
    'mongodb': {
        'NAME': 'db_migration',
        'HOST': 'localhost',
        'PORT': 27017,
    },
    'cassandra': {
        'NAME': 'db_migration',
        'HOST': 'localhost',
        'PORT': 9042,
        'USER': 'cassandra',
        'PASSWORD': 'cassandra',
    }
}

# ... (other settings)

