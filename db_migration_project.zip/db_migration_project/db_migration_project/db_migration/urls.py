from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from core.views import home, migration, data_view, procedures, statistics, dashboard, schedule, schema, export, audit, auth

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home.home, name='home'),
    path('migrate/', migration.migrate_data, name='migrate_data'),
    path('view/', data_view.view_data, name='view_data'),
    path('execute/', procedures.execute_procedure, name='execute_procedure'),
    path('statistics/', statistics.migration_statistics, name='migration_statistics'),
    path('dashboard/', dashboard.dashboard, name='dashboard'),
    path('schedule/', schedule.schedule_migration, name='schedule_migration'),
    path('compare-schemas/', schema.compare_schemas, name='compare_schemas'),
    path('export/', export.export_data, name='export_data'),
    path('download/<str:file_name>/', export.download_export, name='download_export'),
    path('audit-log/', audit.view_audit_log, name='audit_log'),
    path('register/', auth.register, name='register'),
    path('login/', auth.user_login, name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
]

